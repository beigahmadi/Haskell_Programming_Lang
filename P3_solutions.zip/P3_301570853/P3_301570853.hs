-- Mahdi Beigahmadi
-- Student ID: 301570853
-- CMPT383, Programming Assignment 3
-- March 2025

module Main where

import System.Environment (getArgs)
import System.IO (readFile)
import qualified Data.Map.Strict as Map

data Type = TInt
          | TBool
          | TArr Type Type
          deriving (Eq, Ord, Read, Show)

type VarId = String

data Expr = CInt Int
          | CBool Bool
          | Var VarId
          | Plus Expr Expr
          | Minus Expr Expr
          | Equal Expr Expr
          | ITE Expr Expr Expr
          | Abs VarId Type Expr
          | App Expr Expr
          | LetIn VarId Type Expr Expr
          deriving (Eq, Ord, Read, Show)

type Env = Map.Map VarId Type

typingArith :: Maybe Type -> Maybe Type -> Maybe Type
typingArith (Just TInt) (Just TInt) = Just TInt
typingArith _ _ = Nothing

typingEq :: Maybe Type -> Maybe Type -> Maybe Type
typingEq (Just TInt) (Just TInt)   = Just TBool
typingEq (Just TBool) (Just TBool) = Just TBool
typingEq _ _ = Nothing

typing :: Env -> Expr -> Maybe Type
typing _ (CInt _) = Just TInt
typing _ (CBool _) = Just TBool
typing env (Var x) = Map.lookup x env
typing env (Plus e1 e2) = typingArith (typing env e1) (typing env e2)
typing env (Minus e1 e2) = typingArith (typing env e1) (typing env e2)
typing env (Equal e1 e2) = typingEq (typing env e1) (typing env e2)
typing env (ITE e1 e2 e3) = case typing env e1 of
                              Just TBool ->
                                let t2 = typing env e2
                                    t3 = typing env e3
                                in if t2 == t3 then t2 else Nothing
                              _ -> Nothing
typing env (Abs x t e) = case typing (Map.insert x t env) e of
                           Just tBody -> Just (TArr t tBody)
                           Nothing -> Nothing
typing env (App e1 e2) = case typing env e1 of
                           Just (TArr tArg tRes) ->
                             if typing env e2 == Just tArg then Just tRes else Nothing
                           _ -> Nothing
typing env (LetIn x t e1 e2) =
    case typing env e1 of
      Just t' -> if t' == t then typing (Map.insert x t env) e2 else Nothing
      Nothing -> Nothing

readExpr :: String -> Expr
readExpr = read

typeCheck :: Expr -> String
typeCheck e = maybe "Type Error" show (typing Map.empty e)

main :: IO ()
main = do
    args <- getArgs
    case args of
      [filePath] -> do
          content <- readFile filePath
          let exprLines = lines content
          let results = map (typeCheck . readExpr) exprLines
          mapM_ putStrLn results
      _ -> putStrLn ""
